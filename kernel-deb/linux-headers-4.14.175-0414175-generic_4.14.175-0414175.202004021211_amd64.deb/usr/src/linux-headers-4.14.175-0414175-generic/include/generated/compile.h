/* This file is auto generated, version 202004021211 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202004021211 SMP Thu Apr 2 16:14:58 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu 7.5.0-3ubuntu1~18.04)"
